export default function Purchases() {
  return <h2 className="text-2xl font-semibold">Purchases</h2>;
}
