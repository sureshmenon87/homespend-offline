export const DEFAULT_ITEMS = [
  { id: "item-apple", name: "Apple", categoryId: "cat-fruit" },
  { id: "item-milk", name: "Milk", categoryId: "cat-grocery" },
];
