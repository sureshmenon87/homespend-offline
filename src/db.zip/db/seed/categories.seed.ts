export const DEFAULT_CATEGORIES = [
  { id: "cat-fruit", name: "Fruits", description: "" },
  { id: "cat-grocery", name: "Groceries", description: "" },
  { id: "cat-transport", name: "Transport", description: "" },
];
