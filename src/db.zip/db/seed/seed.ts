import { db } from "../schema";
import { DEFAULT_CATEGORIES } from "./categories.seed";
import { DEFAULT_ITEMS } from "./items.seed";

export async function seedMasterData() {
  const now = Date.now();

  await db.transaction("rw", db.categories, db.items, async () => {
    await db.categories.bulkAdd(
      DEFAULT_CATEGORIES.map((c) => ({
        ...c,
        createdAt: now,
        updatedAt: now,
      })),
    );

    await db.items.bulkAdd(
      DEFAULT_ITEMS.map((i) => ({
        ...i,
        createdAt: now,
        updatedAt: now,
      })),
    );
  });
}
